# News



## 1.0.0 (initial version)

Provide the functions necessary to estimate a multivariate log-concave density function as well as a multivariate log-concave mixture distribution.