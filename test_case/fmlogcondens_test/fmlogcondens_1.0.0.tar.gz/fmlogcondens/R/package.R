#' @useDynLib fmlogcondens
