# News



## 1.0.0 (initial version)

Provide the functions necessary to estimate a multivariate log-concave density function as well as a multivariate log-concave mixture distribution.



## 1.0.1

* Fixed a memory leak in C

* Some Mac OS X specific fixes for the C code
